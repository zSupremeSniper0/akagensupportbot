# Welcome Bot #
In config.json set your settings such as bot token/prefix

This uses quick.db to set the log channels. 

Command to set welcome messages:
```
w!channel <id>
```
This bot may need some adjusting on the welcome message, font is kinda big etc. This is easy to fix but I didn't since this
is open source

How to use Jimp (For editing this projects welcome message if needed)
https://github.com/Exploit1337/jimp-discordjs

Need help?
Add me on discord: Exploit#1337
